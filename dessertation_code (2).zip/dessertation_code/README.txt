*To run the code: use python 3.10.9*
To install the libraries/dependencies:
1. Open terminal

Create an virtual envirnoment
2. python -m venv stocks
3. stocks\Scripts\activate
4. pip install --upgrade pip
5. pip install -r requirements.txt

To run the files:
1. Open terminal
2. python submision.py (it is for ESG only model) |||||||||||||||| python submission2.py (it is for combined model)
3. use only 45 industry in the dataset and everything is case sensitive